# QueryAPIGate 0.34.2 security pack

Documents for an architecture or vendor-risk review of QueryAPIGate 0.34.2, a self-hosted, source-available
(FSL-1.1-MIT) gateway that serves saved SQL queries as governed REST endpoints, MCP tools, live events and exports.

1. [Architecture overview](ARCHITECTURE.md)
2. [Security questionnaire answers](QUESTIONNAIRE.md)
3. [Threat model](THREAT_MODEL.md)
4. [Where data goes](DATA_PROTECTION.md)
5. [Security policy](SECURITY.md)
6. [Production deployment](DEPLOYMENT.md)
7. [SBOM and release verification](SBOM.md)

Built from the documentation in the repositories at 0.34.2. Source: https://github.com/AnanthaRajuC/QueryAPIGate
